export const environment = {
  production: false,
  capChannel: 'dev'
};