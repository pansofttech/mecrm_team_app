export const environment = {
  production: false,
  capChannel: 'staging'
};