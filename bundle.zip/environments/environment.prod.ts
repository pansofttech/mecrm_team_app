export const environment = {
  production: true,
  capChannel: 'production'
};